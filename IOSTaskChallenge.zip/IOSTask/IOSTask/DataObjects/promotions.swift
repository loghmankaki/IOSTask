//
//  promotions.swift
//  IOSTask
//
//  Created by majid on 8/20/20.
//  Copyright © 2020 NiKa. All rights reserved.
//

import Foundation
struct promotion {
    var image = String()
}
