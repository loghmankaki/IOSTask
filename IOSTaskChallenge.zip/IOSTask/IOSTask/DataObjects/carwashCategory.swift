//
//  carwashCategory.swift
//  IOSTask
//
//  Created by majid on 8/20/20.
//  Copyright © 2020 NiKa. All rights reserved.
//

import Foundation
struct carwashCategory {
    var image = String()
    var title = String()
    var subTitle = String()
    var descriptions = String()
    var shortDescription = String()
    var price = Int()
    var basePrice = Int()
    var discountPercentage = Int()
    var hasDiscount = Int()
    var isSpecial = Int()
}
