//
//  pageheader.swift
//  IOSTask
//
//  Created by majid on 8/20/20.
//  Copyright © 2020 NiKa. All rights reserved.
//

import Foundation
struct pageHeader {
    var slug = String()
    var title = String()
    var subTitle = String()
    var image = String()
    var slogan = String()
    var description = String()
}
