//
//  services.swift
//  IOSTask
//
//  Created by majid on 8/20/20.
//  Copyright © 2020 NiKa. All rights reserved.
//

import Foundation
struct service {
    var title = String()
    var subTitle = String()
    var description = String()
    var shortDescription = String()
    var image = String()
    var hasNewBadge = Int()
    
//    init(title: String?, subTitle: String?, description: String?, shortDescription: String?, image: String?, hasNewBadge: Int? ) {
//      self.title = title!
//      self.subTitle = subTitle!
//      self.description = description!
//      self.shortDescription = shortDescription!
//      self.image = image!
//      self.hasNewBadge = hasNewBadge!
//    }
}
