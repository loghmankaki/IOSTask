//
//  servicesCollectionViewCell.swift
//  IOSTask
//
//  Created by majid on 8/16/20.
//  Copyright © 2020 NiKa. All rights reserved.
//

import UIKit

class servicesCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var hasNewBadge: UILabel!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var subtitle: UILabel!
    @IBOutlet weak var descriptions: UILabel!
    @IBOutlet weak var shortDescription: UILabel!

    
}
