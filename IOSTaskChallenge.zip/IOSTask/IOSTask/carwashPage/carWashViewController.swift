//
//  carWashViewController.swift
//  IOSTask
//
//  Created by majid on 8/14/20.
//  Copyright © 2020 NiKa. All rights reserved.
//

import UIKit


class carWashViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    var carwashCategories = [carwashCategory]()
    let carwash = getdata()

    @IBOutlet weak var Headerimage: UIImageView!
    @IBOutlet weak var Headerslogan: UILabel!
    @IBOutlet weak var Headerdescription: UILabel!
    @IBOutlet weak var Headerslug: UIButton!
    @IBOutlet weak var collectionView: UICollectionView!
    
    let currency = ".00 QAR"
    let isSpecialColor = "#103AC1"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        carwashCategories.removeAll()
        
        carwash.GetDataFromCarwashAPI( completionBlock: {cat,header in
            self.carwashCategories = cat
            DispatchQueue.main.async {
                //carwash page header data
                self.Headerslug.titleLabel?.text = "← " + header.slug
                self.Headerslogan.text = header.slogan
                self.Headerdescription.text = header.description
                let url = URL(string: header.image)
                let data = try? Data(contentsOf: url!)
                if let imageData = data {
                    self.Headerimage.image = UIImage(data: imageData)
                }
                //carwash categories collection view
                self.collectionView.reloadData()
           }
       })
        
        //categories cell layout
        collectionView?.contentInset = UIEdgeInsets(top: 12, left: 12, bottom: 12, right: 12)
        if let layout = collectionView?.collectionViewLayout as? servicePageLayout {
            layout.delegate = self
        }
    }
    
//................convert hex color to UIColor...................
  func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()

        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }

        if ((cString.count) != 6) {
            return UIColor.gray
        }

        var rgbValue:UInt64 = 0
        Scanner(string: cString).scanHexInt64(&rgbValue)

        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
//.............collection view delegates..........................
       func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
           return carwashCategories.count
       }
       
       func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
           let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! carwashCollectionViewCell
           cell.title.text = carwashCategories[indexPath.row].title
           cell.subtitle.text = carwashCategories[indexPath.row].subTitle
           cell.descriptions.text = carwashCategories[indexPath.row].shortDescription
           
           let url = URL(string: carwashCategories[indexPath.row].image)
           let data = try? Data(contentsOf: url!)

           if let imageData = data {
               cell.image.image = UIImage(data: imageData)
           }
           
           cell.price.text = String(carwashCategories[indexPath.row].price) + currency
        //if hasdiscount was true then show the discount percentage and price with discount
           if carwashCategories[indexPath.row].hasDiscount != 0{
               cell.discountTag.text = " %" + String(carwashCategories[indexPath.row].discountPercentage) + " "
               let attributeString: NSMutableAttributedString =  NSMutableAttributedString(string: String(carwashCategories[indexPath.row].basePrice) + currency)
               attributeString.addAttribute(NSAttributedString.Key.strikethroughStyle, value: 1, range: NSMakeRange(0, attributeString.length))
               cell.discount.attributedText = attributeString
           }
           cell.discountTag.layer.cornerRadius = 8
           cell.discountTag.layer.masksToBounds = true
           
           cell.mainView.layer.cornerRadius = 25

        //show shadow on cells
           cell.contentView.layer.cornerRadius = 25
           cell.contentView.layer.borderWidth = 4.0
           cell.contentView.layer.borderColor = UIColor.clear.cgColor
           cell.contentView.layer.masksToBounds = true
           cell.layer.shadowColor = UIColor.gray.cgColor
           cell.layer.shadowOffset = CGSize(width: 0, height: 2.0)
           cell.layer.shadowRadius = 4.0
           cell.layer.shadowOpacity = 0.6
           cell.layer.masksToBounds = false
           cell.layer.shadowPath = UIBezierPath(roundedRect:cell.bounds, cornerRadius:cell.contentView.layer.cornerRadius).cgPath
         //if isspecial was true the cell color changed
           if carwashCategories[indexPath.row].isSpecial != 0{
               cell.mainView.backgroundColor = hexStringToUIColor(hex: isSpecialColor)
               cell.title.textColor = .white
               cell.subtitle.textColor = .white
               cell.descriptions.textColor = .white
               cell.layer.shadowColor = (hexStringToUIColor(hex: isSpecialColor)).cgColor
           }
           return cell
       }
    
}
extension carWashViewController : servicePageLayoutDelegate {
    func collectionView(_ collectionView: UICollectionView, heightForPhotoAtIndexPath indexPath:IndexPath) -> CGFloat {
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, widthForPhotoAtIndexPath indexPath:IndexPath) -> CGFloat {
        return 0
    }
}
