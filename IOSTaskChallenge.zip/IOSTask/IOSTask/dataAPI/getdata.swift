//
//  getdata.swift
//  IOSTask
//
//  Created by majid on 8/14/20.
//  Copyright © 2020 NiKa. All rights reserved.
//


import Foundation
class getdata {

    var defaultSession: DHURLSession = URLSession(configuration: URLSessionConfiguration.default)
    var searchResultsServices = [service]()
    var searchResultsPromotions = [promotion]()
    var searchResultsHomePageHeader = pageHeader()

    var searchResultsCarwash = [carwashCategory]()
    var searchResultsCarwashPageHeader = pageHeader()
//..............................................................................
    func GetDataFromCarwashAPI(completionBlock:@escaping ([carwashCategory],pageHeader) -> ()){

        let baseURL = "https://api-dot-rafiji-staging.appspot.com/customer/v2/categories/carwash/services"
        let APIKey = ""
        let RequestURL = URL(string: "\(baseURL)?APPID=\(APIKey)")

        var task: URLSessionDataTask?
        task = defaultSession.dataTask(with: RequestURL!) {(data, response, error) in
            if error != nil{
                print("error is \(String(describing: error))")
                return;
            }
            self.parseServicePageData(data: data!)
            completionBlock(self.searchResultsCarwash,self.searchResultsCarwashPageHeader)
        }
        task!.resume()
    }
    
//..............................................................................
     func GetDataFromHomePageAPI(completionBlock:@escaping ([service],[promotion],pageHeader) -> () ){

        let baseURL = "https://api-dot-rafiji-staging.appspot.com/customer/v2/home"
        let APIKey = ""
        let RequestURL = URL(string: "\(baseURL)?APPID=\(APIKey)")
    
        var task: URLSessionDataTask?
        task = defaultSession.dataTask(with: RequestURL!) {(data, response, error) in
        if error != nil{
            print("error is \(String(describing: error))")
            return;
        }
        self.parseHomePageData(data: data!)
            completionBlock(self.searchResultsServices,self.searchResultsPromotions, self.searchResultsHomePageHeader)
        }
        task!.resume()
    }
    
//..............................................................................
     func parseHomePageData(data: Data){
        do {
            let Data = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as! NSDictionary
            searchResultsHomePageHeader.title  = Data["title"]! as! String
            searchResultsHomePageHeader.subTitle  = Data["subTitle"]! as! String
            
            let data:NSArray = Data["categories"]! as! NSArray
            for n in 0..<data.count {
                let row:NSDictionary = data[n] as! NSDictionary
                var tempCategory = service()
                tempCategory.title = row["title"]! as! String
                tempCategory.subTitle = row["subTitle"]! as! String
                tempCategory.description = row["description"]! as! String
                tempCategory.shortDescription = row["shortDescription"]! as! String
                tempCategory.hasNewBadge = row["hasNewBadge"]! as! Int
                let imageser:NSDictionary = row["image"]! as! NSDictionary
                tempCategory.image  = imageser["originalUrl@3x"] as! String
                self.searchResultsServices.append(tempCategory)
            }
            let dataP:NSArray = Data["promotions"]! as! NSArray
            for n in 0..<data.count {
                let row:NSDictionary = dataP[n] as! NSDictionary
                var tempPromotion = promotion()
                let imageser:NSDictionary = row["image"]! as! NSDictionary
                tempPromotion.image  = imageser["originalUrl"] as! String
                searchResultsPromotions.append(tempPromotion)
            }
        }
        catch  {
            print(error)
        }
    }
//..............................................................................
      func parseServicePageData(data: Data){
        do {
            let Data = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as! NSDictionary
                searchResultsCarwashPageHeader.slug  = Data["slug"]! as! String
                searchResultsCarwashPageHeader.title  = Data["title"]! as! String
                searchResultsCarwashPageHeader.slogan  = Data["slogan"]! as! String
                searchResultsCarwashPageHeader.description  = Data["description"]! as! String
                let image:NSDictionary = Data["image"]! as! NSDictionary
                searchResultsCarwashPageHeader.image  = image["originalUrl@3x"] as! String
            
            let data:NSArray = Data["data"]! as! NSArray
            for n in 0..<data.count {
                let row:NSDictionary = data[n] as! NSDictionary
                var tempCarwashType = carwashCategory()
                tempCarwashType.title = row["title"]! as! String
                tempCarwashType.subTitle = row["subTitle"]! as! String
                tempCarwashType.shortDescription = row["shortDescription"]! as! String
                tempCarwashType.discountPercentage = row["discountPercentage"]! as! Int
                tempCarwashType.hasDiscount = row["hasDiscount"]! as! Int
//                    tempCarwashType.discountPercentage = 50 //just for testing percentage
//                    tempCarwashType.hasDiscount = 1         //just for testing percentage
                tempCarwashType.basePrice = row["basePrice"]! as! Int
                let percentage: Double = Double(tempCarwashType.basePrice) - ((Double(tempCarwashType.discountPercentage)/100) * Double(tempCarwashType.basePrice))
                tempCarwashType.price = Int(percentage)
                tempCarwashType.isSpecial = row["isSpecial"]! as! Int
                
                let imageser:NSDictionary = row["image"]! as! NSDictionary
                tempCarwashType.image  = imageser["originalUrl@3x"] as! String
                self.searchResultsCarwash.append(tempCarwashType)
            }
        }
        catch  {
            print(error)
        }
    }
}
