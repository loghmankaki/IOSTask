//
//  promotionCollectionViewCell.swift
//  IOSTask
//
//  Created by majid on 8/16/20.
//  Copyright © 2020 NiKa. All rights reserved.
//

import UIKit

class promotionCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var mainView: UIView!
}
