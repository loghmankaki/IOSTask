//
//  carwashCollectionViewCell.swift
//  IOSTask
//
//  Created by majid on 8/14/20.
//  Copyright © 2020 NiKa. All rights reserved.
//

import UIKit

class carwashCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var discountTag: UILabel!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var subtitle: UILabel!
    @IBOutlet weak var descriptions: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var discount: UILabel!
}
