//
//  ViewController.swift
//  IOSTask
//
//  Created by majid on 8/13/20.
//  Copyright © 2020 NiKa. All rights reserved.
//

import UIKit


class mainViewcontroller: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    var categories = [service]()
    var promotions = [promotion]()
    var homepageHeader = pageHeader()
    
    let homepage = getdata()
    
    let bordercolor = "#F0F1F5"
    let NewBadgeTitle = " NEW "
    
    @IBOutlet weak var servicesCollectionView: UICollectionView!
    @IBOutlet weak var promotionCollectionView: UICollectionView!
    @IBOutlet weak var profileHeaderView: UIView!
    @IBOutlet weak var headerTitle: UILabel!
    @IBOutlet weak var headersubTitle: UILabel!
    @IBOutlet weak var tabbarView: UIView!
    @IBOutlet weak var headerView: UIView!
   

    override func viewDidLoad() {
        super.viewDidLoad()
        categories.removeAll()
        promotions.removeAll()
        
        homepage.GetDataFromHomePageAPI(completionBlock: {cat,pro,header  in
            self.categories = cat
            self.promotions = pro
           DispatchQueue.main.async {
                self.headerTitle.text = header.title
                self.headersubTitle.text = header.subTitle
                
                self.servicesCollectionView.reloadData()
                self.promotionCollectionView.reloadData()
           }
        })
        
        servicesCollectionView.delegate = self
        servicesCollectionView.dataSource = self
        
        promotionCollectionView.delegate = self
        promotionCollectionView.dataSource = self
        
        servicesCollectionView.backgroundColor = .clear
        promotionCollectionView.backgroundColor = .clear
        
        headerView.roundCorners(corners: [.bottomLeft,.bottomRight], radius: 24)
        tabbarView.roundCorners(corners: [.topLeft,.topRight], radius: 24)
        
        profileHeaderView.addBorder(edge: [.bottom], color: hexStringToUIColor(hex: bordercolor), thickness: 1.0)

        
        if let layout = servicesCollectionView?.collectionViewLayout as? UICollectionViewFlowLayout{
                layout.minimumLineSpacing = 24
                layout.minimumInteritemSpacing = 0
                layout.sectionInset = UIEdgeInsets(top: 0, left: 24, bottom: 0, right: 0)
            let size = CGSize(width:(servicesCollectionView!.bounds.width-72)/2, height: 190)
                layout.itemSize = size
        }
       if let layoutPromotion = promotionCollectionView?.collectionViewLayout as? UICollectionViewFlowLayout{
               layoutPromotion.minimumLineSpacing = 24
               layoutPromotion.minimumInteritemSpacing = 0
               layoutPromotion.sectionInset = UIEdgeInsets(top: 0, left: 24, bottom: 0, right: 0)
           let size = CGSize(width:(promotionCollectionView!.bounds.width-48), height: 130)

               layoutPromotion.itemSize = size
       }
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()

        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        var rgbValue:UInt64 = 0
        Scanner(string: cString).scanHexInt64(&rgbValue)
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
     //.............collection view delegates..........................
        func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            if collectionView == servicesCollectionView && indexPath.row == 0{
                performSegue(withIdentifier: "carwashSegue", sender: nil)
            }
        }
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            if collectionView == servicesCollectionView{
                return categories.count
            }else{
                return promotions.count
            }
        }
        
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            if collectionView == servicesCollectionView{
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! servicesCollectionViewCell
                cell.title.text = categories[indexPath.row].title
                cell.subtitle.text = categories[indexPath.row].subTitle
                cell.shortDescription.text = categories[indexPath.row].shortDescription
                if categories[indexPath.row].hasNewBadge != 0{
                    cell.hasNewBadge.text = NewBadgeTitle
                    cell.hasNewBadge.layer.cornerRadius = 5
                }
                let url = URL(string: categories[indexPath.row].image)
                let data = try? Data(contentsOf: url!)
                if let imageData = data {
                    cell.image.image = UIImage(data: imageData)
                }
                
                cell.mainView.layer.cornerRadius = 24
                
                //show shadow on cells
                cell.contentView.layer.cornerRadius = 25
                cell.contentView.layer.borderWidth = 4.0
                cell.contentView.layer.borderColor = UIColor.clear.cgColor
                cell.contentView.layer.masksToBounds = true
                cell.layer.shadowColor = UIColor.gray.cgColor
                cell.layer.shadowOffset = CGSize(width: 0, height: 2.0)
                cell.layer.shadowRadius = 2.0
                cell.layer.shadowOpacity = 0.6
                cell.layer.masksToBounds = false
                cell.layer.shadowPath = UIBezierPath(roundedRect:cell.bounds, cornerRadius:cell.contentView.layer.cornerRadius).cgPath
                return cell
            }else{
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellP", for: indexPath) as! promotionCollectionViewCell
                let url = URL(string: promotions[indexPath.row].image)
                let data = try? Data(contentsOf: url!)

                if let imageData = data {
                    cell.image.image = UIImage(data: imageData)
                }
                cell.mainView.layer.cornerRadius = 25
                
                //show shadow on cells
                cell.contentView.layer.cornerRadius = 25
                cell.contentView.layer.borderWidth = 4.0
                cell.contentView.layer.borderColor = UIColor.clear.cgColor
                cell.contentView.layer.masksToBounds = true
                cell.layer.shadowColor = UIColor.gray.cgColor
                cell.layer.shadowOffset = CGSize(width: 0, height: 2.0)
                cell.layer.shadowRadius = 2.0
                cell.layer.shadowOpacity = 0.6
                cell.layer.masksToBounds = false
                cell.layer.shadowPath = UIBezierPath(roundedRect:cell.bounds, cornerRadius:cell.contentView.layer.cornerRadius).cgPath
                return cell
            }
        }
}

extension UIView {
   func roundCorners(corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        layer.mask = mask
    }
    func shadow(borderWidth: CGFloat,shadowRadius: CGFloat, shadowOpacity: Float,shadowColor: CGColor) {
        
        layer.borderWidth = borderWidth
        layer.borderColor = UIColor.clear.cgColor
        layer.masksToBounds = true
        layer.shadowColor = shadowColor
        layer.shadowOffset = CGSize(width: 0, height: 2.0)
        layer.shadowRadius = shadowRadius
        layer.shadowOpacity = shadowOpacity
        layer.masksToBounds = false
        layer.shadowPath = UIBezierPath(roundedRect:bounds, cornerRadius:layer.cornerRadius).cgPath
    }
    func addBorder(edge: UIRectEdge, color: UIColor, thickness: CGFloat) {
       let border = CALayer()
       switch edge {
       case UIRectEdge.top:
           border.frame = CGRect(x: 0, y: 0, width: frame.width, height: thickness)
       case UIRectEdge.bottom:
           border.frame = CGRect(x:0, y: frame.height - thickness, width: frame.width, height:thickness)
       case UIRectEdge.left:
           border.frame = CGRect(x:0, y:0, width: thickness, height: frame.height)
       case UIRectEdge.right:
           border.frame = CGRect(x: frame.width - thickness, y: 0, width: thickness, height: frame.height)
       default: do {}
       }
       border.backgroundColor = color.cgColor
        layer.addSublayer(border)
    }
}
