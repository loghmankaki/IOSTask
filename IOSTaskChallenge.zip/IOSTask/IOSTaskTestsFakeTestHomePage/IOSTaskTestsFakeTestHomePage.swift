//
//  IOSTaskTestsFakeTestHomePage.swift
//  IOSTaskTestsFakeTestHomePage
//
//  Created by majid on 8/19/20.
//  Copyright © 2020 NiKa. All rights reserved.
//

import XCTest
@testable import IOSTask
class IOSTaskTestsFakeTestHomePage: XCTestCase {
    var sut: mainViewcontroller!

    override func setUp() {
      super.setUp()
        sut = UIStoryboard(name: "Main", bundle: nil).instantiateInitialViewController()  as? mainViewcontroller
        
        let testBundle = Bundle(for: type(of: self))
        let path = testBundle.path(forResource: "abbaData", ofType: "json")
        let data = try? Data(contentsOf: URL(fileURLWithPath: path!), options: .alwaysMapped)

        let url =
          URL(string: "https://api-dot-rafiji-staging.appspot.com/customer/v2/home")
        let urlResponse = HTTPURLResponse(
          url: url!,
          statusCode: 200,
          httpVersion: nil,
          headerFields: nil)

        let sessionMock = URLSessionMock(data: data, response: urlResponse, error: nil)
        sut.homepage.defaultSession = sessionMock
    }

    override func tearDown() {
      sut = nil
      super.tearDown()
    }
    
    func test_UpdateSearchResults_ParsesData() {
      // given
      let promise = expectation(description: "Status code: 200")

      // when
      XCTAssertEqual(
        sut.homepage.searchResultsServices.count,
        0,
        "searchResults should be empty before the data task runs")
      let url =
        URL(string: "https://api-dot-rafiji-staging.appspot.com/customer/v2/home")
        let dataTask = sut.homepage.defaultSession.dataTask(with: url!) {
        data, response, error in
        // if HTTP request is successful, call updateSearchResults(_:)
        // which parses the response data into Tracks
        if let error = error {
          print(error.localizedDescription)
        } else if let httpResponse = response as? HTTPURLResponse,
          httpResponse.statusCode == 200 {
 
            self.sut.homepage.parseHomePageData(data: data!)

            
        }
        promise.fulfill()
      }
      dataTask.resume()
      wait(for: [promise], timeout: 5)

      // then
        XCTAssertEqual(sut.homepage.searchResultsServices.count, 2, "Didn't parse 2 items from fake response")
        XCTAssertEqual(sut.homepage.searchResultsPromotions.count, 2, "Didn't parse 2 items from fake response")
        XCTAssertEqual(sut.homepage.searchResultsHomePageHeader.title, "Book Now!", "Didn't parse header title items from fake response")

    }
    
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

   

}
